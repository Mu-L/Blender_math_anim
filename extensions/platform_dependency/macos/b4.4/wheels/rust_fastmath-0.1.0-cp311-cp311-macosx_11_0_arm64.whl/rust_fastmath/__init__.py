from .rust_fastmath import *

__doc__ = rust_fastmath.__doc__
if hasattr(rust_fastmath, "__all__"):
    __all__ = rust_fastmath.__all__